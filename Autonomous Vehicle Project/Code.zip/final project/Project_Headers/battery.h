/*
 * battery.h
 *
 *  Created on: Jun 5, 2017
 *      Author: maoryak
 */

#include "TFC.h"
#ifndef BATTERY_H_
#define BATTERY_H_

void BattLedConfig ();
void BattLedState (double BattSamp);
void PrintBattery();

#endif /* BATTERY_H_ */
