/*
 * motoros.h
 *
 *  Created on: May 24, 2017
 *      Author: maoryak
 */

#ifndef MOTORS_H_
#define MOTORS_H_
#include "TFC.h"

void MotorConfig();
void EncoderConfig();
void EncoderChecker();
#endif /* MOTORS_H_ */
