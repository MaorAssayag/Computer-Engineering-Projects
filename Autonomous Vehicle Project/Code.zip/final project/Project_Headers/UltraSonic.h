/*
 * UltraSonic.h
 *
 *  Created on: Jun 14, 2017
 *      Author: maoryak
 */

#ifndef ULTRASONIC_H_
#define ULTRASONIC_H_

void UltraSonicConfig();
void PrintDistance();
void UltraSonicSensing();
void UltraSonic_Sensor();
#endif /* ULTRASONIC_H_ */
