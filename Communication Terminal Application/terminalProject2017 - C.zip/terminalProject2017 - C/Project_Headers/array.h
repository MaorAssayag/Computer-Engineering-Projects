/*
 * array.h
 *
 *  Created on: Aug 08, 2017
 *      Author: refael
 */

#ifndef ARRAY_H_
#define ARRAY_H_
#include "TFC.h"
void initarray();
char out();
void in(char a);
char outT();
void inT(char a);
char isempty();
int currnt;
#endif /* ARRAY_H_ */
