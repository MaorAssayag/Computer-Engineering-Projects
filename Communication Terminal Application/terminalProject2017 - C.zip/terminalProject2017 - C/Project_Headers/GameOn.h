/*
 * GameOn.h
 *
 *  Created on: Aug 16, 2017
 *      Author: refael
 */

#ifndef GAMEON_H_
#define GAMEON_H_
#include "TFC.h"

void sendPara();
void updatePara();
void ChangePara(int ChangeArr[],int newbaudRate);
void gameon();
#endif /* GAMEON_H_ */
